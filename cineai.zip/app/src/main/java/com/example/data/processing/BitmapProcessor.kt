package com.example.data.processing

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import android.util.Base64
import androidx.core.content.FileProvider
import com.example.data.model.MediaItemEntity
import com.example.data.model.PresetEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

object BitmapProcessor {

    /**
     * Loads a Bitmap from a Content URI.
     */
    suspend fun loadBitmapFromUri(context: Context, uri: Uri, maxDimension: Int = 1920): Bitmap? = withContext(Dispatchers.IO) {
        try {
            var inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream?.close()

            var sampleSize = 1
            while ((options.outWidth / sampleSize) > maxDimension || (options.outHeight / sampleSize) > maxDimension) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            inputStream = context.contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
            inputStream?.close()
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Converts a Bitmap to a Base64 string for Gemini Multimodal API calls.
     */
    suspend fun bitmapToBase64(bitmap: Bitmap, maxDimension: Int = 800): String = withContext(Dispatchers.IO) {
        val scaled = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
            val scale = maxDimension.toFloat() / maxOf(bitmap.width, bitmap.height)
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true)
        } else {
            bitmap
        }

        val outputStream = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        val byteArray = outputStream.toByteArray()
        Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }

    /**
     * Saves a Bitmap to app internal storage under the "images" directory.
     */
    suspend fun saveBitmapToInternalStorage(context: Context, bitmap: Bitmap, fileName: String = "cine_${UUID.randomUUID()}.jpg"): File = withContext(Dispatchers.IO) {
        val imagesDir = File(context.filesDir, "images")
        if (!imagesDir.exists()) {
            imagesDir.mkdirs()
        }
        val file = File(imagesDir, fileName)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
            out.flush()
        }
        file
    }

    /**
     * Generates a high-quality stylized sample scene Bitmap if local URI is absent.
     */
    suspend fun generateSampleSceneBitmap(sampleKey: String, width: Int = 1280, height: Int = 720): Bitmap = withContext(Dispatchers.Default) {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        when (sampleKey) {
            "landscape" -> {
                // Sky gradient
                val skyShader = android.graphics.LinearGradient(
                    0f, 0f, 0f, height * 0.5f,
                    intArrayOf(0xFF009688.toInt(), 0xFF00BCD4.toInt(), 0xFF80DEEA.toInt()),
                    null, Shader.TileMode.CLAMP
                )
                paint.shader = skyShader
                canvas.drawRect(0f, 0f, width.toFloat(), height * 0.5f, paint)

                // Mountains
                paint.shader = null
                paint.color = 0xFF0F4C5C.toInt()
                val path1 = android.graphics.Path().apply {
                    moveTo(0f, height * 0.45f)
                    lineTo(width * 0.25f, height * 0.25f)
                    lineTo(width * 0.5f, height * 0.35f)
                    lineTo(width * 0.75f, height * 0.22f)
                    lineTo(width.toFloat(), height * 0.45f)
                    close()
                }
                canvas.drawPath(path1, paint)

                // Valley
                paint.color = 0xFFC59B27.toInt()
                canvas.drawRect(0f, height * 0.45f, width.toFloat(), height * 0.65f, paint)

                // Road
                paint.color = 0xFF785B3A.toInt()
                val road = android.graphics.Path().apply {
                    moveTo(width * 0.48f, height * 0.48f)
                    lineTo(width * 0.52f, height * 0.48f)
                    lineTo(width * 0.85f, height.toFloat())
                    lineTo(width * 0.15f, height.toFloat())
                    close()
                }
                canvas.drawPath(road, paint)
            }
            "fjord" -> {
                // Emerald Sky & Mountains
                paint.color = 0xFF80CBC4.toInt()
                canvas.drawRect(0f, 0f, width.toFloat(), height * 0.4f, paint)
                paint.color = 0xFF134E4A.toInt()
                canvas.drawRect(0f, height * 0.35f, width.toFloat(), height * 0.55f, paint)
                // Sea
                paint.color = 0xFF00695C.toInt()
                canvas.drawRect(0f, height * 0.55f, width.toFloat(), height.toFloat(), paint)
            }
            "cyberpunk" -> {
                paint.color = 0xFF090A0F.toInt()
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
                paint.color = 0xFFE11D48.toInt()
                canvas.drawCircle(width * 0.3f, height * 0.4f, 150f, paint)
                paint.color = 0xFF06B6D4.toInt()
                canvas.drawCircle(width * 0.7f, height * 0.6f, 180f, paint)
            }
            else -> {
                paint.color = 0xFF2B2930.toInt()
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
                paint.color = 0xFFD0BCFF.toInt()
                canvas.drawCircle(width * 0.5f, height * 0.5f, 200f, paint)
            }
        }
        bitmap
    }

    /**
     * Applies full cinematic grade & AI unblur processing on a Bitmap.
     */
    suspend fun processCinematicBitmap(
        source: Bitmap,
        unblurStrength: Float,
        contrast: Float,
        exposure: Float,
        saturation: Float,
        warmth: Float,
        tint: Float,
        vignette: Float,
        grain: Float,
        letterboxRatio: String = "2.39:1",
        presetId: String = "teal_orange"
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = source.width
        val height = source.height

        // 1. Apply Sharpen / Unblur convolution kernel if unblurStrength > 0
        val sharpened = if (unblurStrength > 5f) {
            applySharpenKernel(source, unblurStrength)
        } else {
            source.copy(Bitmap.Config.ARGB_8888, true)
        }

        // 2. Apply ColorMatrix (Contrast, Exposure, Saturation, Warmth, Tint & Preset LUT Matrix)
        val gradedBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(gradedBitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val colorMatrix = buildCinematicColorMatrix(
            contrast = contrast,
            exposure = exposure,
            saturation = saturation,
            warmth = warmth,
            tint = tint,
            presetId = presetId
        )
        paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
        canvas.drawBitmap(sharpened, 0f, 0f, paint)

        // 3. Apply Vignette if enabled
        if (vignette > 5f) {
            applyVignette(canvas, width, height, vignette)
        }

        // 4. Apply 35mm Film Grain Noise if enabled
        if (grain > 5f) {
            applyFilmGrain(canvas, width, height, grain)
        }

        // 5. Apply Letterbox Bars (2.39:1 Anamorphic, 16:9, etc.)
        if (letterboxRatio != "None") {
            applyLetterbox(canvas, width, height, letterboxRatio)
        }

        gradedBitmap
    }

    /**
     * Fast Unsharp Mask / Sharpening filter using spatial 3x3 convolution kernel.
     */
    private fun applySharpenKernel(source: Bitmap, strength: Float): Bitmap {
        val width = source.width
        val height = source.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val pixels = IntArray(width * height)
        val outPixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        val weight = (strength / 100f).coerceIn(0f, 1.5f)
        val center = 1f + 4f * weight
        val edge = -weight

        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val idx = y * width + x
                val top = (y - 1) * width + x
                val bottom = (y + 1) * width + x
                val left = y * width + (x - 1)
                val right = y * width + (x + 1)

                val pC = pixels[idx]
                val pT = pixels[top]
                val pB = pixels[bottom]
                val pL = pixels[left]
                val pR = pixels[right]

                val a = (pC ushr 24) and 0xFF
                var r = (((pC ushr 16) and 0xFF) * center +
                        (((pT ushr 16) and 0xFF) + ((pB ushr 16) and 0xFF) + ((pL ushr 16) and 0xFF) + ((pR ushr 16) and 0xFF)) * edge).roundToInt()
                var g = (((pC ushr 8) and 0xFF) * center +
                        (((pT ushr 8) and 0xFF) + ((pB ushr 8) and 0xFF) + ((pL ushr 8) and 0xFF) + ((pR ushr 8) and 0xFF)) * edge).roundToInt()
                var b = ((pC and 0xFF) * center +
                        ((pT and 0xFF) + (pB and 0xFF) + (pL and 0xFF) + (pR and 0xFF)) * edge).roundToInt()

                r = r.coerceIn(0, 255)
                g = g.coerceIn(0, 255)
                b = b.coerceIn(0, 255)

                outPixels[idx] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        output.setPixels(outPixels, 0, width, 0, 0, width, height)
        return output
    }

    /**
     * Builds comprehensive 4x5 ColorMatrix combining LUT presets and manual parameters.
     */
    private fun buildCinematicColorMatrix(
        contrast: Float,
        exposure: Float,
        saturation: Float,
        warmth: Float,
        tint: Float,
        presetId: String
    ): ColorMatrix {
        val cm = ColorMatrix()

        // Saturation base
        val satFactor = (1f + (saturation / 50f)).coerceIn(0f, 3f)
        cm.setSaturation(satFactor)

        // Contrast scale
        val cScale = (1f + (contrast / 50f)).coerceIn(0.2f, 3f)
        val cTranslate = (-0.5f * cScale + 0.5f) * 255f
        val contrastMatrix = ColorMatrix(floatArrayOf(
            cScale, 0f, 0f, 0f, cTranslate,
            0f, cScale, 0f, 0f, cTranslate,
            0f, 0f, cScale, 0f, cTranslate,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(contrastMatrix)

        // Exposure & Temperature/Tint
        val expVal = (exposure / 50f) * 60f
        val warmR = (warmth / 50f) * 35f
        val warmB = -(warmth / 50f) * 35f
        val tintG = -(tint / 50f) * 25f
        val tintM_R = (tint / 50f) * 15f
        val tintM_B = (tint / 50f) * 15f

        val colorShiftMatrix = ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, expVal + warmR + tintM_R,
            0f, 1f, 0f, 0f, expVal + tintG,
            0f, 0f, 1f, 0f, expVal + warmB + tintM_B,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(colorShiftMatrix)

        // LUT Preset specific color balance
        val lutMatrix = when (presetId) {
            "teal_orange" -> ColorMatrix(floatArrayOf(
                1.15f, 0f, 0f, 0f, 18f,
                0f, 1.05f, 0f, 0f, 5f,
                0f, 0f, 1.25f, 0f, -10f,
                0f, 0f, 0f, 1f, 0f
            ))
            "nordic_emerald" -> ColorMatrix(floatArrayOf(
                0.90f, 0f, 0f, 0f, -10f,
                0f, 1.20f, 0f, 0f, 15f,
                0f, 0f, 1.15f, 0f, 12f,
                0f, 0f, 0f, 1f, 0f
            ))
            "cyberpunk_neon" -> ColorMatrix(floatArrayOf(
                1.30f, 0f, 0f, 0f, 25f,
                0f, 0.85f, 0f, 0f, -15f,
                0f, 0f, 1.35f, 0f, 30f,
                0f, 0f, 0f, 1f, 0f
            ))
            "vintage_35mm" -> ColorMatrix(floatArrayOf(
                1.15f, 0f, 0f, 0f, 22f,
                0f, 1.05f, 0f, 0f, 12f,
                0f, 0f, 0.85f, 0f, -15f,
                0f, 0f, 0f, 1f, 0f
            ))
            "monochrome_noir" -> {
                val bw = ColorMatrix()
                bw.setSaturation(0f)
                bw
            }
            "bleach_bypass" -> ColorMatrix(floatArrayOf(
                1.25f, 0f, 0f, 0f, 10f,
                0f, 1.25f, 0f, 0f, 10f,
                0f, 0f, 1.25f, 0f, 10f,
                0f, 0f, 0f, 1f, 0f
            ))
            "wes_anderson" -> ColorMatrix(floatArrayOf(
                1.20f, 0f, 0f, 0f, 28f,
                0f, 1.15f, 0f, 0f, 18f,
                0f, 0f, 0.95f, 0f, -5f,
                0f, 0f, 0f, 1f, 0f
            ))
            else -> ColorMatrix()
        }
        cm.postConcat(lutMatrix)

        return cm
    }

    private fun applyVignette(canvas: Canvas, width: Int, height: Int, vignetteStrength: Float) {
        val cx = width / 2f
        val cy = height / 2f
        val radius = maxOf(cx, cy) * 1.3f
        val alpha = ((vignetteStrength / 100f) * 230).roundToInt().coerceIn(0, 255)

        val vignetteShader = RadialGradient(
            cx, cy, radius,
            intArrayOf(0x00000000, 0x00000000, (alpha shl 24) or 0x000000),
            floatArrayOf(0.0f, 0.45f, 1.0f),
            Shader.TileMode.CLAMP
        )
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = vignetteShader
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    private fun applyFilmGrain(canvas: Canvas, width: Int, height: Int, grainStrength: Float) {
        val count = (width * height * (grainStrength / 100f) * 0.008f).toInt().coerceIn(500, 15000)
        val random = Random(42)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt()
            alpha = ((grainStrength / 100f) * 90).roundToInt().coerceIn(10, 120)
            strokeWidth = 1.5f
        }

        for (i in 0 until count) {
            val x = random.nextFloat() * width
            val y = random.nextFloat() * height
            canvas.drawPoint(x, y, paint)
        }
    }

    private fun applyLetterbox(canvas: Canvas, width: Int, height: Int, ratio: String) {
        val targetAspect = when (ratio) {
            "2.39:1" -> 2.39f
            "16:9" -> 16f / 9f
            "4:3" -> 4f / 3f
            "9:16" -> 9f / 16f
            else -> return
        }

        val currentAspect = width.toFloat() / height.toFloat()
        val paint = Paint().apply {
            color = 0xFF000000.toInt()
            style = Paint.Style.FILL
        }

        if (targetAspect > currentAspect) {
            // Letterbox (top & bottom bars)
            val activeHeight = width / targetAspect
            val barHeight = (height - activeHeight) / 2f
            if (barHeight > 0f) {
                canvas.drawRect(0f, 0f, width.toFloat(), barHeight, paint)
                canvas.drawRect(0f, height - barHeight, width.toFloat(), height.toFloat(), paint)
            }
        } else if (targetAspect < currentAspect) {
            // Pillarbox (left & right bars)
            val activeWidth = height * targetAspect
            val barWidth = (width - activeWidth) / 2f
            if (barWidth > 0f) {
                canvas.drawRect(0f, 0f, barWidth, height.toFloat(), paint)
                canvas.drawRect(width - barWidth, 0f, width.toFloat(), height.toFloat(), paint)
            }
        }
    }

    /**
     * Creates an Intent to share the processed media file.
     */
    fun createShareIntent(context: Context, file: File): Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        return Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
